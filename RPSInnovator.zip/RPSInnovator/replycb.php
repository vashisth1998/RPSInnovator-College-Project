<?php

include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{



?>


<!DOCTYPE html>
<html>
<head>
<title>Complaint box Reply</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="http://code.jquery.com/jquery-1.9.0rc1.js"></script>

</head>
<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
<a href='RPSInnovator.php' style='color:black;text-decoration:none;'>RPSInnovator</a>

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="home.php">Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name']; ?></a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
</div><br/>
<hr/>
<hr/>
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Reply On Post</center>
</div>
<div class="panel-body">
<?php

if(isset($_GET['cid']))
{
	 $id=$_GET['cid'];
	 $show="select * from complaint_box where complaint_id=$id";
$run_show=mysqli_query($con,$show);
while($s=mysqli_fetch_array($run_show))
{
$cid=$s['complaint_id'];
$uname=$s['complaint_user_name'];
$utitle=$s['complaint_title'];
$udetails=$s['comlaint_box'];
$dates=$s['date'];
echo "<div class='well'>
<b> Name</b>:<font color='red'>$uname</font><br/>
<b>Complaint Title:</b>$utitle<br/>
<b>Complaint Details:</b>$udetails<br/> 
<b>Date</b>:$dates<br/>
</div>";


}
}











$show_reply_querys="select * from  replycomplaintbox where complaint_id=$cid ";
$run_replys=mysqli_query($con,$show_reply_querys);
while($check=mysqli_fetch_array($run_replys))
{

	$replier_name=$check['reply_name'];
	$replier_comment=$check['comment'];
	echo "<div class='well'>
	<font color='red'>$replier_name</font>&nbsp;<br/>
	<b>$replier_comment</b>
	</div>";


}
?>
<div class="well">
<form action="#" method="post">
<div class="form-group">
<input class="form-control" type="text" required="required" placeholder="Enter your reply" name="rbox"/>
<input type="submit" name="rsubmit" style='color:white;background:blue;' />
</div>
</form>
<?php
if(isset($_POST['rsubmit']))
{
	$rcomment=$_POST['rbox'];
	
	 $reply_query="insert into replycomplaintbox(reply_name,complaint_id,complaint_by,date,comment) values('$name','$cid','$uname',NOW(),'$rcomment')";
	$run_reply_query=mysqli_query($con,$reply_query);
	if($run_reply_query)
	{
	echo "<script>alert('Reply Successful! Check Your Reply ')</script>";

}
}




?>
</div>
</div>
</div>
</body>


</html>
<?php } ?>