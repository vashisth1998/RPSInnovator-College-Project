
<!DOCTYPE html>
<html>
<head>
<title>RPSInnovator</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>

</head>
<body>
<!----navbar starts here--->
<div class="navbar navbar-default navbar-fixed-top">

<div class="container-fluid">
<div class="navbar-header">
<a href="#" class="navbar-brand"><span class=" glyphicon glyphicon-home"></span> RPSInnovator</a>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#button" >
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<!---unordered list project starts from here---->
<ul class="nav navbar-nav navbar-right">
<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> <strong>Login</strong></a></li>
<li><a href="rpsinnovator.php"><span class="glyphicon glyphicon-user"></span> <strong>Register</strong></a></li>
</ul>
<!---unordered list project ends here add link to directly redirect them--->
<!---header navigation complete here ---->
</div>
<!---container fluid ends here---->
</div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<div class="container-fluid">
<div class="jumbotron">
<div class="row">
<div class="col-sm-6">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
Login to RPSInnovator
</div>
<div class="panel-body">
<form action="#" method="post">
<div class="form-group">
<b>Libary Card Number:</b><input type="text" class="form-control" name="libcard" placeholder="Enter your libary card number" required="required"/><br/>
<b>Password:</b><input type="password" class="form-control" name="pass" placeholder="Enter Your Password" required="required"/><br/>
<button class="btn btn-primary" name="ulogin" >Login</button>&emsp;&emsp;&emsp;<a href="rpsinnovator.php" class="btn btn-danger" name="register">Register </a>
</div><!---form class ends here--->
</form>
<?php
include "connection.php";
session_start();
if(isset($_POST['ulogin']))
{
 $lib=$_POST['libcard'];
 $pass=$_POST['pass'];
 
   $check_query="select * from users_details WHERE user_libaraycard='$lib' AND user_password='$pass'";
$run_query=mysqli_query($con,$check_query);
$row=mysqli_fetch_array($run_query);
$libcard_number=$row['user_libaraycard'];
$libcard_password=$row['user_password'];

if($lib==$libcard_number AND $pass==$libcard_password)
{
	  $_SESSION['user_libaraycard']=$lib;
	echo "<script>alert('you have successfullly logined into your account');</script>";
	echo "<script>location.href='home.php';</script>";
}	
else
{
	echo "Sorry!Something Went Wrong!Let us Know Email us!";
}
}



?>
</div><!---panel body ends here--->
</div>
</div>
<div class="col-sm-6">
<ul>
<li>Libary Card Number should be correct</li>
<li>Password should be secure and it is recommedating that greather than 8 digits</li>
<li>Email us rpsinnovator@gmail.com</li>
</ul>
</div>
</div>
</div><!--classs col 1 ends here--->
</div><!---div ends here for row--->
</body>
</html>