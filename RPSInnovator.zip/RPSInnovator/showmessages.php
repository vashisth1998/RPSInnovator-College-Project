<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Student ARea[Engineer Rocks!!]</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Student Messenge Inbox!!]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!-----navbar ends here---->
<div class="jumbotron">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>My Message[One Inbox]</center>
</div>
<div class="panel-body">

<?php

$query="select * from mymessage where receiver='$libno'";
$run=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run))
{
	
	 $sendercard=$row['sender'];
	 $title=$row['msg_title'];
	 $msg_details=$row['msg_detail'];
	$query1="select * from  users_details  where user_libaraycard='$sendercard'";
$run1=mysqli_query($con,$query1);
$rowq=mysqli_fetch_array($run1);
 $name=$rowq['user_name'];	

 echo "<div class='well'><b><font color='red'>Message Title</font></b>:&emsp;$title<br/>
 <b><font color='red'>Message</b></font>:&emsp;$msg_details<br/>
 <b><font color='red'>Sender Name</font></b>:&emsp;$name<br/>

 </div>
  <hr/>
 ";

 }






?>

</div>
</div>
</body>
</html>