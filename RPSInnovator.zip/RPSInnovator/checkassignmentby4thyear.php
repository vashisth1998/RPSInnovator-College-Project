<?php
include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<title>Check Assignment</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[TeacherARea-Document]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<br/>
<br/>
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Check Assignment Submission by 4th Year Student</center>
</div>
<div class="panel-body">
<?php
if(isset($_GET['branch']))
{
	 $s_year=$_GET['branch'];
  $selectquery="select * from  assignmentbystudents where teacher_id='$libno' AND branch_year='$s_year' ";
$run_query=mysqli_query($con,$selectquery);
while($rows=mysqli_fetch_array($run_query))
{
	  $sendername=$rows['student_id'];
	  $assignmenttitle=$rows['assignment_title'];
	  $assignment_file=$rows['assignment_file'];
$query1="select * from users_details where user_libaraycard='$sendername'";
$run1=mysqli_query($con,$query1);
$row1=mysqli_fetch_array($run1);
$sender=$row1['user_name'];
	echo "<div class='well'>
	
	<font color='red'>Assignment Title</font>:$assignmenttitle<br/>
	<font color='red'>Assignment</font>: $assignment_file<br/>
	<font color='red'>Sent By</font>: $sender<br/>
	

	</div>";
	
}
	echo "<hr/>";


}



?>


</div>





</div>






</body>
</html>
<?php } ?>