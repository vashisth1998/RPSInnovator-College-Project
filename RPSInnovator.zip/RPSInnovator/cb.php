<?php

include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{



?>


<!DOCTYPE html>
<html>
<head>
<title>Complaint box</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="http://code.jquery.com/jquery-1.9.0rc1.js"></script>


<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
<a href='RPSInnovator.php' style='color:black;text-decoration:none;'>RPSInnovator</a>

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="home.php">Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name']; ?></a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
</div><br/>
<hr/>

<center>
<h1 class="bg-primary">RPS INNOVATION</h1>
</center>
<div>
	<dl>
	<dt><h2>Complaint Box :<h2></></dt>
	<dd><b>Let us Know Your Complaint Regarding College or Our Website.We will Try to fix out as soon as possible.</b></dd>
	</dl>
</div>
<form action="#" method="post">
<div class="form-group">
Complaint  Title:<input type="text" name="title"  class="form-control" placeholder="Complaint Title" required="required"/><br/>
Complaint Box:<textarea class="form-control" class="form-control" placeholder="Write here your complaint" name="details" required="required"></textarea><br/>
</div>
<center><input type="submit" value="SUBMIT" name="submit" class="btn btn-default btn-danger"></center>
</form>
<?php

if(isset($_POST['submit']))
{
	$title=$_POST['title'];
	 $detail=$_POST['details'];
	 
	 $query1="insert into complaint_box(complaint_user_name,complaint_user_card,complaint_title,comlaint_box,date) values('$name','$libno','$title','$detail',NOW())";
$run1=mysqli_query($con,$query1);
if($run1)
{
	echo "<script>alert('Complaint Has been submitted')</script>";
}
else
{
	echo "<script>alert('Complaint Failed')</script>";
}
	
}





?><br/>
<br/>

<div class="well"><center><font color="red">Complaint From Users</font></center></div>
<?php



$show="select * from complaint_box ORDER BY date DESC";
$run_show=mysqli_query($con,$show);
while($s=mysqli_fetch_array($run_show))
{
$cid=$s['complaint_id'];
$uname=$s['complaint_user_name'];
$utitle=$s['complaint_title'];
$udetails=$s['comlaint_box'];
$dates=$s['date'];
echo "<div class='well'>
<b> Name</b>:$uname<br/>
<b>Complaint Title:</b>$utitle<br/>
<b>Complaint Details:</b>$udetails<br/> 
<b>Date</b>:$dates<br/>
<b><a href='replycb.php?cid=$cid'>Reply </a></b>
</div>";






}




?>

</body>
</head>
</html>
<?php } ?>