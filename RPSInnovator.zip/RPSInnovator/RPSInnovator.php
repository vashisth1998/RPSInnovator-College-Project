
<!DOCTYPE html>
<html>
<head>
<title>RPSInnovator</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
<!-- Insert to your webpage before the </head> -->
    <script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
    <!-- End of head section HTML codes -->
</head>
<body>
<!----

Looking for Source Code>>Common Leave a mail at rpsinnovator@gmail.com...
We will provide you...............................
<<<
>>>>
<<<<<{Want to join Us}
>>>>>>>
<<<<<<<<<
>>>>>>>>>>>
<<<<<<<<<<<<<
>>>>>>>>>>>>>>





--->
<!----navbar starts here--->
<div class="navbar navbar-default navbar-fixed-top">

<div class="container-fluid">
<div class="navbar-header">
<a href="#" class="navbar-brand"><span class=" glyphicon glyphicon-home"></span> RPSInnovator</a>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#button" >
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>
<!---unordered list project starts from here---->
<ul class="nav navbar-nav navbar-right">
<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> <strong>Login</strong></a></li>
<li><a href="rpsinnovator.php"><span class="glyphicon glyphicon-user"></span> <strong>Register</strong></a></li>
</ul>
<!---unordered list project ends here add link to directly redirect them--->
<!---header navigation complete here ---->
</div>
<!---container fluid ends here---->
</div>
<!---navbar ends here---->
<!-- Insert to your webpage where you want to display the slider -->
   <hr/>
   <div class="jumbotron">
	<div id="amazingslider-wrapper-1" style="display:block;position:relative;max-width:960px;margin:0px auto 56px;">
        <div id="amazingslider-1" style="display:block;position:relative;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
                <li><img src="images/1.jpg" class="img-responsive" alt="1"  title="1" />
                </li>
                <li><img src="images/2.jpg" class="img-responsive" alt="2"  title="2" />
                </li>
                <li><img src="images/3.jpg" class="img-responsive" alt="3"  title="3" />
                </li>
            </ul>
            <ul class="amazingslider-thumbnails" style="display:none;">
                <li><img src="images/1-tn.jpg" class="img-responsive" alt="1" title="1" /></li>
                <li><img src="images/2-tn.jpg" class="img-responsive" alt="2" title="2" /></li>
                <li><img src="images/3-tn.jpg" class="img-responsive"  alt="3" title="3" /></li>
            </ul>
        </div>
    </div>
	
<br/>
<br/>
	<div class="panel panel-default panel-primary">
	<div class="panel-heading">
	<center>About RPSInnovator</center>
	</div>
	
	<div class="panel-body">
	<p><a href="RPSInnovator.php">RPSInnovator</a> is an online portal where Student and Teacher can interact online.Here on RPSInnovator teacher can check student details and information.
	They can share their notes with student and they can upload student marks and assignment online.
	The main purpose behind this project is to save time and papers and make student digital.
	You can use RPSInnovator:</p>
	<ol>
	<li>Check Date and Time For Sessional Exams</li>
	<li>Send Personal Message to Professors</li>
	<li>Can share your creativity and projects</li>
	<li>Check Notice</li>
	<li>Share Documents with each other </li>
	<li>Can do Confess </li>
	</p>
	</div>
	</div>
	<br/>
	<div class="row">
	<div class="col-sm-8">
	<div class="panel panel-default panel-danger">
	<div class="panel-heading">
	Registeration Form
	</div>
	<div class="panel-body">
	<!---register--->
	<form action="#" method="post">
<div class="form-group"><!---used for bootstrap form application-->
<label for="wtitle"><h4><b><span class="glyphicon glyphicon-pushpin"></span>Full Name</b></h4></label>
<input type="text" class="form-control" name="uname"  id="wtitle" placeholder="Enter your Full Name" required="required"/>
</div>

<div class="form-group">
<label for="wname"><h4><b><span class="glyphicon glyphicon-text-color"></span> Libary Card Number</b></h4></label>
<input type="text" class="form-control" id="wname" name="ulibcard" placeholder="Enter your Libary Card Number" required="required"/>

</div>
<div class="form-group">
<label for="wcontent"><h4><b><span class="glyphicon glyphicon-envelope"></span>Branch</b></h4></label>
<textarea rows="3"  name="ubranch"  class="form-control" id="wcontent" placeholder="Enter your Branch" required="required"></textarea>

</div>
<hr/>
<b>Select Your Year</b>:<select name="year" required="required">
<option>Select Your Btech/BCA/MCA Year</option>
<option>1st year</option>
<option>2nd year</option>
<option>3rd year</option>
<option>4th year</option>

</select>
<hr/>
<div class="form-group">
<label for="wkeywords"><h4><b><span class="glyphicon glyphicon-check"></span>Address</b></h4></label>
<input type="text" class="form-control" name="uaddress" id="wkeywords" placeholder="Enter your Full Address" required="required"/>
</div>
<div class="form-group">
<label for="wpassword"><h4><b><span class="glyphicon glyphicon-check"></span>Secure Password</b></h4></label>
<input type="password" class="form-control" name="upass" id="wpassword" placeholder="Enter your Secure Password" required="required"/>
</div>
<center>
<button class="btn btn-info"  name="usubmit">Register</button>&emsp;<a href="rpsinnovator.php" class="btn btn-danger" name="reset">Reset</a>
</center>

</div><!---div tag ends here for class form group-->
<!-----backend coding starts from here-------------------------->

</form>

	</div>
	<?php
	
	include "connection.php";

$con=mysqli_connect("localhost","root","","rpsinnovator");
if(isset($_POST['usubmit']))
{
	 $name=$_POST['uname'];
	 $lib_card=$_POST['ulibcard'];
	 $branch=$_POST['ubranch'];
$address=$_POST['uaddress'];
$password=$_POST['upass'];
echo $years=$_POST['year'];
$con=mysqli_connect("localhost","root","","rpsinnovator");


if(strlen($password)<8)
{
	echo "<script>alert('please make strong password and more than 8 characters');</script>";
}
$run_query="select * from users_details where user_libaraycard='$lib_card'";
$make_me=mysqli_query($con,$run_query);
$row=mysqli_fetch_array($make_me);
 $lib_id=$row['user_libaraycard'];
if($lib_card==$lib_id)
{
	echo "<script>alert('Account has already Made!Contact Us if you Forgot Account!');</script>";
}
else
{
$make_query="insert into users_details(user_name,user_password,user_libaraycard,user_branch,user_address,user_profile,user_reg_date,branch_year) values('$name','$password','$lib_card','$branch','$address','userprofileimag/',NOW(),$years)";
	 if(mysqli_query($con,$make_query))
	{
		echo "<script>alert('Thanks!Account has been created');</script>";
		echo "<script>location.href='login.php'</script>";
	}
	else
	{
		echo "<script>alert('Submission failed')</script>";
	}
	
	
}
}

?>
	</div>
	<div class="col-sm-4">
	<div class="panel panel-default panel-info">
	<div class="panel-heading">
	<center>Instructions</center>
	</div>
	<div class="panel-body">
	<ol>
	<li><b>Make Ensure you are using correct <font color="red">Libary Card</font></b></li>
	<li><b>Make Ensure you are using Secure password and should be more than 8 digits.Use Letters,numbers and symbol to make it more secure</b></li>
	<li><b>Your Address should be correct</b></li>
	<li><b>Please Mention Full Branch details/In which Btech Year</b></li>
	<li><b>Dont Try to disturb the enviornment of Website.Otherwise you will strictly banned from website</li>
	<li><b>If you wanna join Our Team Please leave a mail rpsinnovator@gmail.com</b></li>
	</ol>
	
	</div>
	</div>
	</div>
	</div>
	<hr/>
	<br/>
	
    <!-- End of body section HTML codes -->
<div class="navbar navbar-inverse">
<div class="container-fluid">

<div class="navbar-header">
<a href="#" class="navbar-brand"><span class=" glyphicon glyphicon-home"></span> RPSInnovator</a>
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#button" >
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
</div>

<!---unordered list project starts from here---->
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> <strong>About Us</strong></a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> <strong>Term and Conditions</strong></a></li>
<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> <strong>Copyright Policies</strong></a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> <strong>Send Bug Report</strong></a></li>
</ul>

<!---unordered list project ends here add link to directly redirect them--->
<!---header navigation complete here ---->
</div>
</div>
<hr/>
</div>
<div class="well">
<center><font color="red"><b><i>&copy 2017 RPSInnovator &nbsp;[Website Made with love and Patience by Rahul Vashisth for CSE Department]</i></b></font></center>
</div>
</body>




</html>
