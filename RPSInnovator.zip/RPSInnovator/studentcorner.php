<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Student ARea[Engineer Rocks!!]</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Student ARea-Engineer Rocks!!]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!-----navbar ends here---->
<div class="jumbotron">
<div class="row">
<div class="col-sm-8">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Write Your Confession</center>
</div>
<div class="panel-body">
<div class="well"><b>Your Confession Should be in appropriate Manner and Doesnot Violates Our Privacy.<a href="#">Privacy Confession</a></b></div>
<form action="#" method="post" enctype="multipart/form-data">
<div class="form-group">
Confession Title:<input type="text" name="title"  class="form-control" placeholder="Confession Title" required="required"/><br/>
Confession:<textarea class="form-control" class="form-control" placeholder="I Like to Make a Project On ROBOTICS.Seeking For a Team?Anyone Interested" name="details" required="required"></textarea><br/>
</div>
<center><input type="submit" value="Do Confess" name="submit" class="btn btn-default btn-danger"></center>
</form>
<hr/>
<?php


if(isset($_POST['submit']))
{
	 $title=$_POST['title'];
	 $details=$_POST['details'];
	


$final_update="insert into student_confession(user_name,user_libcard,date,confession_title,confession) values('$name','$libno',NOW(),'$title','$details')";
$final_update=mysqli_query($con,$final_update);
if($final_update)
{
	echo "<script>alert('Confess Successful!');</script>";
	echo "<script>location.href='studentcorner.php'</script>";
}
else
{
	echo "<script>alert('Document Failed.Did you check up your Format? Try again or leave us Message')</script>";
}


	 
}







?>
</div>

</div><!---panel ends here---->
</div><!----row 1st col-sm-8 ends here ---->
<!----row 1st col-sm-4 starts from here---->
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Choose Your Choice</center>
</div>
<div class="panel-body">

<b>Check Recent Timetable:</b>&emsp;<a href="showtimetable.php" class="btn btn-primary">Check Timetable</a>
<br/><hr/>
<b>Check Recent Documents:</b>&emsp;<a href="documentstore.php" class="btn btn-info">Check Document</a>
<br/><hr/>
<b>Check Recent Assignment:</b>&emsp;<a href="#" class="btn btn-danger">Check Assignment</a>
<br/><hr/>
<b>Check Class Marks:</b>&emsp;<a href="#" class="btn btn-info">Check Class Marks</a>
<br/><hr/>
<b>Check Recent Notice:</b>&emsp;<a href="shownotice.php" class="btn btn-primary">Check Recent Notice</a>
<br/><hr/>
<b>Check Teacher :</b>&emsp;<a href="teacherdetails.php" class="btn btn-info">Click Here</a>
<br/><hr/>

</div>
</div><!---panel ends here---->
</div><!----row 1st col-sm-4 ends here ---->
<!--row 1st col-sm-4 ends here---->

</div>
</div>
<div class="jumbotron">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center><b><h4>Recent Confess History</h4></b></center>
</div>
<div class="panel-body">

<?php
$query="select * from student_confession order by date desc";
$run_query=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run_query))
{

	$id=$row['confess_id'];
	 $name=$row['user_name'];
	 $card=$row['user_libcard'];
     $date=$row['date'];	
	 $title=$row['confession_title'];
	 $post_content=$row['confession'];

	 echo "
	 <b>Confess Title </b>:$title<br/>
	 <b>Confess Details is</b>:$post_content<br/>
<b>Confess By</b>:<a href='studentdetails.php?card=$card'>$name</a> On <b>$date</b>

	 ";

}
?>



</div>
</div>
</div>
</body>
</html>