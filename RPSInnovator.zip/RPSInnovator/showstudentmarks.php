<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Show[StudentMarks]</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Show-StudentMarks]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Download StudentMarks</center>
</div>
<div class="paenl-body">
<?php
$query="select * from  teacher_studentmarks where user_name='$name' order by date desc";
$run_query=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run_query))
{
	$id=$row['sheet_id'];
	 $name=$row['user_name'];
	 $card=$row['user_libcard'];
     $date=$row['date'];	
	 $title=$row['sheet_title'];
	$document=$row['marksheet'];
	 echo "<div class='well'>
	 <b>Marksheet Title is</b>:$title<br/>

	 <b>Marksheet Download</b>:$document<br/>
	 <b>Date and Time</b>:$date<br/>
	 <a href='download3.php?id=$id'>Click Here To Download</a>
	 </div>";
}

?>

</div>
</div>
</body>
</html>