<?php
include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{






?>
<!DOCTYPE html>
<html>
<head>
<title>Upload Your Assignment</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Send Your Assignment]

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name']; 
$user_profile=$run['user_profile'];
$student_year=$run['branch_year'];?></a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
</div><br/><br/>
<br/>
<br/>
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Upload your Assignment</center>
</div>
<div class="panel-body">
<div class="row">
<div class="col-sm-8">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Upload Assignment Section</center>
</div>
<div class="panel-body">
<div class="well">
<center><b>Your Assignment should be in <font color="red">docx/pdf</font> format only.</b></center>
</div>
<form action="#" enctype="multipart/form-data" method="post">
<div class="form-group">

Assignment Title:<input type="text"  class="form-control" name="assignmenttitle" required="required"/><br/>
<center><input type="file"   name="filetoupload" class="btn btn-danger" required="required"/><br/>
</center>
<br/>
<center><input type="submit" name="submitassignment"  class="btn btn-info" required="required"/></center>






</div>
</form>
<?php
if(isset($_GET['card']))
{
	 $receivercardnumber=$_GET['card'];
	 $sendercardnumber=$libno;

if(isset($_POST['submitassignment']))
{
	
 $title=$_POST['assignmenttitle'];
$file_name=$_FILES['filetoupload']['name'];
$file_tmp=$_FILES['filetoupload']['tmp_name'];
$store="assignmentbystudents/".$file_name;
if(move_uploaded_file($file_tmp,$store))
{
	
	$insert_query="insert into assignmentbystudents(student_id,teacher_id,assignment_title,assignment_file,date,branch_year) values('$sendercardnumber','$receivercardnumber','$title','$file_name',NOW(),'$student_year')";
	$run_query=mysqli_query($con,$insert_query);
	if($run_query)
	{
	echo "<script>alert('Your assignment has been submitted!Thank you');</script>";	

	}
	else
	{
		echo "<script>alert('Server Error contact rpsinnovator@gmail.com');</script>";
	}
	
}
else
{
	echo "<script>alert('Assignment Submission  failed! try again!');</script>";
}

	   

	
	
}	
	
	
}














?>
</div>
</div>
</div>
<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Quick Link</center>
</div>
<div class="panel-body">
<ol>
<li>Check Teacher Profile</li>
<li>Send Messages to Friends</li>
</ol>
</div>
</div>
</div>
</div>
</div>



</div>
</body>
</html>
<?php } ?>