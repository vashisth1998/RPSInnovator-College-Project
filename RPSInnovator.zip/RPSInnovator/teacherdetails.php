<?php
include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{



?>
<!DOCTYPE html>
<html>
<head>
<title>Student ARea[Engineer Rocks!!]</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Student ARea-Teacher Profile Checker!!]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<div class="jumbotron">
<div class="row">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Check Teacher Profile</center>
</div>
<div class="panel-body">
<div class="row">
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Khusboo Yadav</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/khusboo.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="assignmentsentbystudents.php?card=LECT01" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--first column ends here--->
</div>
<!---------------------phase first coulumn --------------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Silpi Sanghi</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/silpi.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column ends here--->
</div>
<!---------------------------phase second column------------------------------>

<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Megha Yadav</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/megha.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column ends here--->
</div>
</div><!---first row ends here--->
<!-------------------------first row ends here--------------------------------->
<hr/>
<div class="row">
<div class="col-sm-4">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Anil Vadhwa </center>
</div>
<div class="panel-body">
<center><img src="teacherpic/anilvadwa.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column  ends here--->
</div>
<!---------------------phase second coulumn --------------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Dr.Rajeev Yadav</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/hod.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column ends here--->
</div>
<!---------------------------phase second column------------------------------>

<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Sarjender  Yadav</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/sarjender.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column ends here--->
</div>
</div><!---second  row ends here--->
<!--------------------second row ends here---------------------------------------->
<!----third row starts from here------------------------------>

<hr/>
<div class="row">
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Prof. S.S Yadav</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/ss.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second row  column  ends here--->
</div>
<!---------------------phase second coulumn --------------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Ramesh Loar</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/ramesh.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--third column ends here--->
</div>
<!---------------------------phase second column------------------------------>

<div class="col-sm-4">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Gundeep Tanwar</center>
</div>
<div class="panel-body">
<center><img src="teacherpic/gundeep.jpg" height="200"  class="img-circle"/><br/><hr/>
<a href="#" class="btn btn-info">Send Message</a><br/><br/>
<a href="#" class="btn btn-primary">Send Assignment</a></center>
</div>
</div><!--second column ends here--->
</div>
</div><!---third ends here--->





























<!----------------third row ends here----------------------->
</div><!---panel body ends here---->
</div>
</div>
</div>
</body>
</html>
<?php } ?>