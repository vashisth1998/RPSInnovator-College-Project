<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Teacher ARea</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[3rd Year Student-Backlog Almost Complete]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];

 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!-----navbar ends here---->
<div class="jumbotron">
<?php
if(isset($_GET['bid']))
{
$student_branch_year=$_GET['bid'];	

$show_all_student="select * from users_details where branch_year='$student_branch_year'"; 
$make_db=mysqli_query($con,$show_all_student);
while($check=mysqli_fetch_array($make_db))
{
	 $name=$check['user_name'];
	 $branch_year=$check['branch_year'];
	 $branch=$check['user_branch'];
$profile=$check['user_profile'];
	$card=$check['user_libaraycard'];
	
	
	echo "<div class='well'>
	<img src='$profile' height='150' width='150'>&emsp;&emsp;<font color='red'><b>$name</b></font>
	&emsp;&emsp;<b>Libary Card Number</b>&emsp;&emsp;<font color='red'>$card</font>
	&emsp;&emsp;<b>Branch</b>&emsp;<font color='red'>$branch</font><br/>
	
	</div>";
	
	
	
}	
	
	
	
	
	}








?>
</div>
</body>
</html>