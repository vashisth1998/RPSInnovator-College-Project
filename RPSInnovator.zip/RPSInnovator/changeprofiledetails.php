<?php
include "connection.php";
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Edit My Profile]

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div><br/>
<br/>
<div class="jumbotron">
<form action="#" method="post">
<center>
<h3><b>Name</b>:<input type="text" name="name" required="required" placeholder="Enter Your Full Name"/><br/></h3>
<h3><b>Branch</b>:<input type="text" name="branch" required="required" placeholder="Enter Your Branch Details"/><br/></h3>
<h3><b>LibCard Number</b>:<input type="text" name="lib" required="required" placeholder="Enter Your Libary Card Number"/><br/></h3>
<h3><b>Email Address</b>:<input type="text" name="email" required="required" placeholder="Enter Your Email"/><br/></h3>
<h3><b>Address</b>:<input type="text" name="address" required="required" placeholder="Enter Your Address"/><br/></h3>
<h3><b>Contact </b>:<input type="text" name="contact" required="required" placeholder="Enter Your Contact Number"/><br/></h4>
<h4><b>Gender</b>:<input type="text" name="gender" required="required" placeholder="Enter Your Gender"/><br/></h4>
<br/>
<input type="submit" class="btn btn-info" name="update"  value="Update Profile"/>&nbsp;&nbsp;&nbsp;
<a href="changeprofiledetails.php" class="btn btn-danger">RESET</a>
</center>
</form>
<?php

if(isset($_POST['update']))
{
	 $name=$_POST['name'];
	 $branch=$_POST['branch'];
	 $card=$_POST['lib'];
	 $email=$_POST['email'];
	 $address=$_POST['address'];
	 $contact=$_POST['contact'];
	$gender=$_POST['gender'];
	
	
	$update_query="update users_details set user_name='$name',user_contact='$contact',user_libaraycard='$card',user_email='$email',
	user_branch='$branch',user_gender='$gender',user_address='$address' where user_libaraycard='$libno'";
	$run=mysqli_query($con,$update_query);
	if($run)
	{
		echo "<script>alert('Your Profile Has been Updated!');</script>";
		echo "<script>location.href='profile.php'</script>";
	}
}








?>



</div>
</body>
</html>