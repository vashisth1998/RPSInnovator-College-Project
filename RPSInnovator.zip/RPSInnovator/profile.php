<?php
include "connection.php";
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[My Profile]

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div><br/>
<br/>
<br/>
<div class="container-fluid">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
My Profile
</div>
<div class="panel-body">
<div class="row">
<div class="col-sm-6">
<?php 
/* select sql query here----*/

$query1="select * from users_details where user_libaraycard='$libno'";
$makes_db_run=mysqli_query($con,$query1);
$run1=mysqli_fetch_array($makes_db_run);
  $name=$run1['user_name'];
  $images=$run1['user_profile'];
echo  "<img src='userprofileimage/$images' width='550' height='200' class='img-responsive'>";
?>

</div>
<!---small column for picture in first row--->
<div class="col-sm-6">
<table class="table-responsive">
<table class="table table-hover">
<tr><td>
<form action="#" method="post" enctype="multipart/form-data">
<b>Select image to upload:</b>
    <input type="file" name="image" id="fileToUpload" class="btn btn-default btn-info"><input type="submit" value="Upload Profile" name="submit" class="btn btn-default btn-danger">
</form>
<br/>
<b><hr/></b>
<b>Change My Profile Details</b> <br/><a href="changeprofiledetails.php" class="btn btn-info">Click Here</a>

<?php
include "connection.php";
if(isset($_POST['submit']))
{
	 $file_name=$_FILES['image']['name'];
	 $file_type=$_FILES['image']['type'];
	$file_tmp=$_FILES['image']['tmp_name'];
	$store='userprofileimage/'.$file_name;
move_uploaded_file($file_tmp,$store);

/*-------now sql query starts here-----*/

 $update_image="update users_details set user_profile='$file_name' where user_libaraycard='$libno'"; 
$make_image_db=mysqli_query($con,$update_image);
if($make_image_db)
{
	echo "<script>alert('Successful!Your Profile Pic has been updated!');</script>";
	echo "<script>location.href='profile.php'</script>";
}	
	
}
?>
</td></tr>
</table><!---first table for its responsive--->
</div><!---small column for pictures in first row 2nd option--->
</div><!---first row in panel body--->
</div>
</div><!---panel body ends here---->
</div><!---panel ends here--->
<div class="panel panel-default panel-danger">
<div class="panel-heading">
Personal Details
</div>
<div class="panel-body">
<center>
<?php
$user_profile="select * from users_details where user_libaraycard='$libno'";
$run_profile=mysqli_query($con,$user_profile);
$row=mysqli_fetch_array($run_profile);
 $name=$row['user_name'];
$user_card=$row['user_libaraycard'];
$branch=$row['user_branch'];
$user_regdate=$row['user_reg_date'];
$address=$row['user_address'];
$contact=$row['user_contact'];
$gender=$row['user_gender'];
$bday=$row['user_bday'];
$email=$row['user_email'];

?>
<h3><b>Name:&nbsp;<?php echo $name; ?></b><br/></h3>
<h3><b>Branch:&nbsp;<?php echo $branch; ?></b><br/></h3>
<h3><b>LibCard Number:&nbsp;<?php echo $user_card; ?></b><br/></h3>
<h3><b>Email Address:&nbsp;<?php echo $email; ?></b><br/></h3>
<h3><b>Address:&nbsp;<?php echo $address; ?></b><br/></h3>
<h3><b>Registeration Date:&nbsp;<?php echo $user_regdate; ?></b><br/></h3>
<h3><b>Contact:&nbsp;<?php echo $contact; ?></b><br/></h3>
<h3><b>Gender:&nbsp;<?php echo $gender; ?></b><br/></h3>
<h3><b>Birthday:&nbsp;<?php echo $bday; ?></b><br/></h3>



</center>
</div>
</div>
<div class="well">
We Protect Your Identity <br/>
Got Some Problem Let us Know,Leave Mail:rahul.vashisth38@gmail.com
</div>
</body>
</html>