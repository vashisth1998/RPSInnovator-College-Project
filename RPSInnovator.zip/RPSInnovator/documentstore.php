<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Teacher ARea</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[DocumentStore]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Download Documents</center>
</div>
<div class="paenl-body">
<?php
$query="select * from teacher_db  where users_name='$name' order by user_date desc";
$run_query=mysqli_query($con,$query);
while($row=mysqli_fetch_array($run_query))
{
	$id=$row['post_id'];
	 $name=$row['users_name'];
	 $card=$row['user_libcard'];
     $date=$row['user_date'];	
	 $title=$row['post_title'];
	 $post_content=$row['post_content'];
	 $document=$row['post_file'];
	 echo "<div class='well'>
	 <b>Document Title is</b>:$title<br/>
	 <b>Document Details is</b>:$post_content<br/>
	 <b>Document Download</b>:$document<br/>
	 <b>Date and Time</b>:$date<br/>
	 <a href='download.php?id=$id'>Click Here To Download</a>
	 </div>";
}

?>

</div>
</div>
</body>
</html>