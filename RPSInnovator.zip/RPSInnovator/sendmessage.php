<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Student ARea[Engineer Rocks!!]</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[Student Messenger!!]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!-----navbar ends here---->
<div class="jumbotron">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Student Message</center>
</div>
<div class="panel-body">
<form action="#" method="post">
<div class="form-group">
<label for="title">Message Title</label>
<input type="text"  id="title" name="mtitle" required="required" class="form-control" placeholder="Enter Please Message Title"/><br/>
<label for="message">Message Detail</label>
<textarea cols="5" rows="4" required="required" class="form-control" placeholder="Enter your Message" id="message" name="mymsg"></textarea><br/>

<input type="submit" name="msubmit" class="btn btn-primary"/>&emsp;&emsp;&emsp;&emsp;<a href="home.php" class="btn btn-danger">Home</a>

</div>
</form>
<?php
global $libno;
if(isset($_GET['card']))
{
	$receiver_card=$_GET['card'];
}
if(isset($_POST['msubmit']))
{
	$msg_title=$_POST['mtitle'];
	 $msg_detail=$_POST['mymsg'];
	 $sender=$libno;
	$receiver=$receiver_card;

	$query="insert into  mymessage(sender,receiver,date,msg_title,msg_detail) values('$sender','$receiver',NOW(),'$msg_title','$msg_detail')";
	$run=mysqli_query($con,$query);
	if($run)
	{
		echo "<script>alert('Message Has been sent')</script>";
	}
	else
	{
		echo "<script>alert('Message Failed!')</script>";
	}
	
	}

?>
</div>
</div>
</div>
</body>
</html>