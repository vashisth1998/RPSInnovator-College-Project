<?php
include "connection.php";
session_start();



?>
<!DOCTYPE html>
<html>
<head>
<title>Notice</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[TeacherARea-Notice]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!-----navbar ends here---->
<div class="jumbotron">
<div class="row">
<div class="col-sm-8">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Upload Notice</center>
</div>
<div class="panel-body">
<div class="well"><b>We Support files in pdf or docx format.If not Please Change Format so that you can upload Successfully. </b></div>
<form action="#" method="post" enctype="multipart/form-data">
<center><b>Select Notice to upload:</b></center><hr/>
<div class="form-group">
Notice Title:<input type="text" name="title"  class="form-control" required="required"/><br/>

</div>
<center><input type="file" name="file" id="fileToUpload"  required="required" class="btn btn-default btn-danger"><br/><hr/><input type="submit" value="Upload Notice" name="submit" class="btn btn-default btn-danger"></center>
</form>
<hr/>
<?php


if(isset($_POST['submit']))
{
	 $title=$_POST['title'];

	 $file_name=$_FILES['file']['name'];
	 $file_size=$_FILES['file']['size'];
	 $file_tmp_name=$_FILES['file']['tmp_name'];
	 $store='teachernotice/'.$file_name;
move_uploaded_file($file_tmp_name,$store);


$final_update="insert into teacher_notice(user_name,user_libcard,date,notice_title,notice) values('$name','$libno',NOW(),'$title','teachernotice/$file_name')";
$final_update=mysqli_query($con,$final_update);
if($final_update)
{
	echo "<script>alert('Notice  Uploaded Successfully');</script>";
	echo "<script>location.href='shownotice.php'</script>";
	
}
else
{
	echo "<script>alert('Document Failed.Did you check up your Format? Try again or leave us Message')</script>";
}


	 
}







?>
</div>
</div><!---panel ends here---->
</div><!----row 1st col-sm-8 ends here ---->
<!----row 1st col-sm-4 starts from here---->
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Choose Your Choice</center>
</div>
<div class="panel-body">
<b>Upload Timetable:</b>&emsp;<a href="timetable.php" class="btn btn-primary">Upload Timetable</a>
<br/><hr/>
<b>Upload Documents:</b>&emsp;<a href="teacher.php" class="btn btn-info">Upload Document</a>
<br/><hr/>
<b>Upload Assignment:</b>&emsp;<a href="#" class="btn btn-danger">Upload Assignment</a>
<br/><hr/>

<b>Upload Student Marks:</b>&emsp;<a href="studentmarks.php" class="btn btn-info">Upload Student Marks</a>
<br/><hr/>
<b>Upload Notice:</b>&emsp;<a href="notice.php" class="btn btn-primary">Upload Notice</a>
<br/><hr/>
<b>Need Help:</b>&emsp;<a href="#" class="btn btn-info">Click Here</a>
<br/><hr/>

</div>
</div><!---panel ends here---->
</div><!----row 1st col-sm-4 ends here ---->
<!--row 1st col-sm-4 ends here---->

</div>
</div>
</body>
</html>