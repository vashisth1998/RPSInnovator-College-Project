<?php

include "connection.php";
session_start();





?>
<!DOCTYPE html>
<html>
<head>
<title>TeacherCorner</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>
</head>
<body>
<div class="navbar navbar-default navbar-top-fixed">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator[TeacherCorner]
</div>
</div>

<ul class="nav navbar-nav navbar-right">
<li><a href="home.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name'];
 ?></a></li>
<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>
</ul>
</div>
</div>
<!----first making of teacher corner panel---->
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Let us Know your Identity.Please Enter following Details.</center>
</div><!---panel heading ends here--->
<div class="panel-body">
<hr/>
<form action="#" method="post">
<div class="form-group">
<label for="libcard">Libaray Card Number</label>
<input type="text" class="form-control" placeholder="Enter your Libaray Card Number"  required="required" name="libcard"/>
</div>
<div class="form-group">
<label for="pass">Password</label>
<input type="password" class="form-control" placeholder="Enter your Password" required="required" name="pass"/>
</div>
<div class="form-group">
<label for="identity">Identity</label>
<input type="password" class="form-control"  placeholder="Enter your Identity" required="required" name="identity"/>
</div>
<button class="btn btn-primary" name="teacherlogin">Let Me Login</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="home.php" class="btn btn-danger" name="homepage">Home</a>
</div>


</div>
</form>
<?php
if(isset($_POST['teacherlogin']))
{
	 $t_libcard=$_POST['libcard'];
	 $t_pass=$_POST['pass'];
	 $t_identity=$_POST['identity'];
	 
	 
	  $verify_query="select * from users_details Where user_libaraycard='$libno'";
	 $make_db=mysqli_query($con,$verify_query);
	 $run=mysqli_fetch_array($make_db);
	 $teacher=$run['teacher_identity'];
	 $password=$run['user_password'];
	 if($teacher==$t_identity AND $t_pass==$password)
	 {
		 echo "<script>alert(' Successful your identity matched up')</script>";
		 echo "<script>location.href='teacher.php'</script>";
		 
	 }
	 else
	 {
		 echo "<script>alert('Identity is not Matched!')</script>";
		
	 }
	
}







?>


<!--- panel making ends here--->



</body>
</html>