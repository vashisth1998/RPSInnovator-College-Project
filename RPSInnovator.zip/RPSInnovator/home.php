<?php
include "connection.php";
session_start();
if(!$_SESSION['user_libaraycard'])
{
	header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html>
<head>
<title>Home</title>
<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet"/>
<script src="js/bootstrap.min.js">
</script>
<script src="js/jquery-3.1.1.js">
</script>

</head>
<body>
<div class="navbar navbar-default navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
<div class="navbar-brand">
RPSInnovator

</div>

</div>
<ul class="nav navbar-nav navbar-right">
<li><a href="#"><span class="glyphicon glyphicon-user"></span> Hi <?php  $libno=$_SESSION['user_libaraycard'];
 $query="select * from users_details where user_libaraycard='$libno'";
$make_db_run=mysqli_query($con,$query);
$run=mysqli_fetch_array($make_db_run);
echo $name=$run['user_name']; 
$user_profile=$run['user_profile'];?></a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</div>
</div><br/>
<div class="jumbotron">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center><b>Select Your Choice</b></center>
</div>
<div class="jumbotron">
<div class="panel-body">
<div class="row">

<!--------------------first row first coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>My Profile</center>
</div>
<div class="panel-body">

<?php
echo "<img src='userprofileimage/$user_profile'  height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="profile.php" class="btn btn-info form-control">Edit My Profile</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------first row first column ends here--------------------->


<!--------------------first row second coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>My Messages</center>
</div>
<div class="panel-body">

<?php
echo "<img src='msg.jpg'  height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="showmessages.php" class="btn btn-danger form-control">Check Messages</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------first row second column ends here--------------------->



<!--------------------first row third coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Student Corner</center>
</div>
<div class="panel-body">

<?php
echo "<img src='student.jpg' height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="studentcorner.php" class="btn btn-primary form-control">Enter Into Student Corner</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------first row third column ends here--------------------->



<!--------------------2nd row starts from here------------------------------------------------>
<div class="row">

<!--------------------second row first coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-primary">
<div class="panel-heading">
<center>Teacher Corner</center>
</div>
<div class="panel-body">

<?php
echo "<img src='teacher.jpg'  height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="teachercorner.php" class="btn btn-info form-control">Enter Into Teacher Corner</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------second row first column ends here--------------------->


<!--------------------second row second coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-danger">
<div class="panel-heading">
<center>Student Timeline/Confess Room</center>
</div>
<div class="panel-body">

<?php
echo "<img src='confess.png'  height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="studenttimeline.php" class="btn btn-danger form-control">Enter Into Student Confess Room</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------second row second column ends here--------------------->



<!--------------------second row third coulumn stats from here---------------------------->
<div class="col-sm-4">
<div class="panel panel-default panel-info">
<div class="panel-heading">
<center>Project Room</center>
</div>
<div class="panel-body">

<?php
echo "<img src='projec.jpg' height='200'  width='400' class='img-responsive img-rounded'/>";
?><br/>
<a href="#" class="btn btn-primary form-control">Share Your Project</a>

</div><!--panel body ends here--->
</div><!---panel ends here--->
</div>
<!------second row third column ends here--------------------->


<!-------------------------2nd row ends from here-------------------------------------------->

<div class="row">
<div class="col-sm-12">
<div class="panel panel-default panel- danger">
<div class="panel-heading">
<center>About Us</center>
</div>
<div class="panel-body">
<center><img src="about.jpg" height="200" class="img-responsive" width="900"/></center><br/>
<a href="#" class="btn btn-primary form-control">Know Team Behind RPSInnovator</a>

</div>
</div>
</div>
</div>



</div>
</div>
</div>
</div>
</div>


</html>
<?php } ?>